package com.spider.app.data.repo

class StreamUrlBuilder(serverUrl: String, private val user: String, private val pass: String) {
    private val base = serverUrl.trim().trimEnd('/')

    fun live(streamId: Int, ext: String = "m3u8") = "$base/live/$user/$pass/$streamId.$ext"
    fun movie(streamId: Int, ext: String?) = "$base/movie/$user/$pass/$streamId.${ext ?: "mp4"}"
    fun episode(episodeId: String, ext: String?) = "$base/series/$user/$pass/$episodeId.${ext ?: "mp4"}"
}
