package com.spider.app.data

import android.content.Context
import android.os.Environment
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

@Serializable
data class DownloadItem(
    val key: String,
    val title: String,
    val poster: String? = null,
    val ext: String,
    val url: String,
    val done: Boolean = false,
    val size: Long = 0L
)

enum class DlStatus { PENDING, RUNNING, PAUSED, DONE, FAILED }

data class DownloadUi(
    val item: DownloadItem,
    val status: DlStatus,
    val done: Long,
    val total: Long,
    val path: String?,
    val error: String? = null
) {
    val percent: Int get() = if (total > 0) ((done * 100) / total).toInt().coerceIn(0, 100) else 0
}

private class Live(
    @Volatile var status: DlStatus,
    @Volatile var done: Long = 0L,
    @Volatile var total: Long = 0L,
    @Volatile var error: String? = null
)

private class HttpFail(val code: Int) : IOException("HTTP $code")

/**
 * تحميل جوه التطبيق: بيكمّل من نقطة التوقف (Range) وبيعيد المحاولة لوحده لو الاتصال اتقطع،
 * وبيحمّل ملف واحد في المرة علشان ما يعدّيش حد الاتصالات في الاشتراك.
 */
class DownloadsStore(ctx: Context) {
    private val appCtx = ctx.applicationContext
    private val prefs = appCtx.getSharedPreferences("downloads2", Context.MODE_PRIVATE)
    private val json = Json { ignoreUnknownKeys = true }
    private val serializer = ListSerializer(DownloadItem.serializer())

    companion object {
        private const val UA = "VLC/3.0.20 LibVLC/3.0.20"
        private const val MAX_ATTEMPTS = 30
        private val lock = Any()
        private val live = ConcurrentHashMap<String, Live>()
        private val jobs = ConcurrentHashMap<String, Job>()
        @Volatile private var suspended = false
        private val gate = Semaphore(1)
        private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        private val client = OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()

        /** عدد التحميلات الشغالة ومتوسط التقدّم، أو null لو مفيش حاجة شغالة */
        fun activeSummary(): Pair<Int, Int>? {
            val act = live.values.filter {
                it.status == DlStatus.PENDING || it.status == DlStatus.RUNNING || it.status == DlStatus.PAUSED
            }
            if (act.isEmpty()) return null
            val pct = act.map { if (it.total > 0) (it.done * 100 / it.total).toInt() else 0 }.average().toInt()
            return act.size to pct
        }
    }

    private fun dir(): File =
        (appCtx.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: appCtx.filesDir).apply { mkdirs() }

    private fun finalFile(i: DownloadItem) = File(dir(), "${i.key}.${i.ext}")
    private fun partFile(i: DownloadItem) = File(dir(), "${i.key}.${i.ext}.part")

    private fun readItems(): List<DownloadItem> = try {
        json.decodeFromString(serializer, prefs.getString("items", "[]") ?: "[]")
    } catch (e: Exception) {
        emptyList()
    }

    private fun writeItems(list: List<DownloadItem>) {
        prefs.edit().putString("items", json.encodeToString(serializer, list)).apply()
    }

    fun items(): List<DownloadItem> = synchronized(lock) { readItems() }

    fun enqueue(key: String, title: String, poster: String?, url: String, ext: String): Boolean {
        val item = DownloadItem(key = key, title = title, poster = poster, ext = ext, url = url)
        synchronized(lock) {
            val cur = readItems()
            if (cur.any { it.key == key }) return false
            writeItems(cur + item)
        }
        start(item)
        return true
    }

    fun remove(key: String) {
        jobs.remove(key)?.cancel()
        live.remove(key)
        var removed: DownloadItem? = null
        synchronized(lock) {
            val cur = readItems()
            removed = cur.firstOrNull { it.key == key }
            writeItems(cur.filter { it.key != key })
        }
        removed?.let {
            finalFile(it).delete()
            partFile(it).delete()
        }
    }

    /** وقف التحميلات مؤقتاً أثناء مشاهدة بث من السيرفر (علشان حد الاتصالات في الاشتراك) */
    fun suspendAll() {
        suspended = true
        jobs.values.forEach { it.cancel() }
        jobs.clear()
        live.values.forEach {
            if (it.status != DlStatus.DONE && it.status != DlStatus.FAILED) {
                it.status = DlStatus.PAUSED
                it.error = "متوقف أثناء المشاهدة"
            }
        }
    }

    fun resumeAll() {
        suspended = false
        items().filter { !it.done }.forEach { item ->
            val st = live[item.key]
            if (st == null || st.status != DlStatus.FAILED) {
                live.remove(item.key)
                start(item)
            }
        }
    }

    /** إعادة المحاولة بتكمّل من اللي اتحمّل قبل كده */
    fun retry(key: String) {
        val item = items().firstOrNull { it.key == key } ?: return
        jobs.remove(key)?.cancel()
        live.remove(key)
        start(item)
    }

    fun refresh(): List<DownloadUi> {
        return items().map { item ->
            val fin = finalFile(item)
            if (item.done) {
                if (fin.exists()) {
                    DownloadUi(item, DlStatus.DONE, item.size, item.size, fin.absolutePath)
                } else {
                    DownloadUi(item, DlStatus.FAILED, 0L, 0L, null, "الملف اتمسح من الموبايل")
                }
            } else {
                var st = live[item.key]
                if (st == null) {
                    start(item) // تحميل ناقص من قبل ما التطبيق يتقفل: كمّل
                    st = live[item.key]
                }
                if (st == null) {
                    DownloadUi(item, DlStatus.PENDING, 0L, 0L, null)
                } else {
                    DownloadUi(item, st.status, st.done, st.total, null, st.error)
                }
            }
        }
    }

    private fun start(item: DownloadItem) {
        if (item.done) return
        if (jobs[item.key]?.isActive == true) return
        if (items().none { it.key == item.key }) return
        val part = partFile(item)
        if (suspended) {
            live[item.key] = Live(
                DlStatus.PAUSED, if (part.exists()) part.length() else 0L, 0L, "متوقف أثناء المشاهدة"
            )
            return
        }
        live[item.key] = Live(DlStatus.PENDING, if (part.exists()) part.length() else 0L, 0L)
        DownloadService.ensureRunning(appCtx)
        jobs[item.key] = scope.launch { download(item) }
    }

    private suspend fun CoroutineScope.download(item: DownloadItem) {
        val st = live[item.key] ?: return
        val part = partFile(item)
        val fin = finalFile(item)
        gate.withPermit {
            var attempt = 0
            while (isActive) {
                try {
                    st.status = DlStatus.RUNNING
                    val have = if (part.exists()) part.length() else 0L
                    val rb = Request.Builder().url(item.url).header("User-Agent", UA)
                    if (have > 0) rb.header("Range", "bytes=$have-")
                    client.newCall(rb.build()).execute().use { resp ->
                        if (resp.code == 416 && have > 0) {
                            // الملف كامل بالفعل
                            finish(item, part, fin, st)
                            return@withPermit
                        }
                        if (!resp.isSuccessful) throw HttpFail(resp.code)
                        val body = resp.body ?: throw IOException("رد فاضي من السيرفر")
                        val append = resp.code == 206 && have > 0
                        val len = body.contentLength()
                        var written = if (append) have else 0L
                        st.total = if (len > 0) written + len else 0L
                        st.done = written
                        st.error = null
                        body.byteStream().use { input ->
                            FileOutputStream(part, append).use { out ->
                                val buf = ByteArray(64 * 1024)
                                while (true) {
                                    ensureActive()
                                    val n = input.read(buf)
                                    if (n < 0) break
                                    out.write(buf, 0, n)
                                    written += n
                                    st.done = written
                                }
                            }
                        }
                        if (st.total > 0 && written < st.total) throw IOException("انقطع الاتصال")
                        finish(item, part, fin, st)
                        return@withPermit
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    attempt++
                    st.error = e.message ?: e.javaClass.simpleName
                    val hard = e is HttpFail && e.code in 400..499 && e.code != 408 && e.code != 429
                    if (hard || attempt >= MAX_ATTEMPTS) {
                        st.status = DlStatus.FAILED
                        return@withPermit
                    }
                    st.status = DlStatus.PAUSED
                    delay(minOf(30_000L, 2_000L * attempt))
                }
            }
        }
    }

    private fun finish(item: DownloadItem, part: File, fin: File, st: Live) {
        if (fin.exists()) fin.delete()
        if (!part.renameTo(fin)) {
            part.copyTo(fin, overwrite = true)
            part.delete()
        }
        val size = fin.length()
        synchronized(lock) {
            writeItems(readItems().map { if (it.key == item.key) it.copy(done = true, size = size) else it })
        }
        st.done = size
        st.total = size
        st.error = null
        st.status = DlStatus.DONE
    }
}
