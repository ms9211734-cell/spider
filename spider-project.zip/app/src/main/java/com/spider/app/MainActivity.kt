package com.spider.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.spider.app.ui.SpiderApp
import com.spider.app.ui.SpiderViewModel

class MainActivity : ComponentActivity() {
    private val vm: SpiderViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SpiderApp(vm) }
    }
}
