package com.spider.app.data

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*

/** خدمة بتخلّي التحميل شغال حتى لو خرجت من التطبيق، وبتعرض إشعار بالتقدّم */
class DownloadService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var monitor: Job? = null

    companion object {
        private const val CHANNEL = "downloads"
        private const val NOTIF_ID = 7

        fun ensureRunning(ctx: Context) {
            val i = Intent(ctx, DownloadService::class.java)
            try {
                if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
            } catch (e: Exception) {
                // مش مسموح من الخلفية: التحميل بيكمّل طالما التطبيق شغال
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        val first = notification("جاري التحميل...", 0)
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIF_ID, first, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            } else {
                startForeground(NOTIF_ID, first)
            }
        } catch (e: Exception) {
        }
        if (monitor?.isActive != true) {
            monitor = scope.launch {
                while (true) {
                    val s = DownloadsStore.activeSummary()
                    if (s == null) {
                        stopForeground(STOP_FOREGROUND_REMOVE)
                        stopSelf()
                        break
                    }
                    val nm = getSystemService(NotificationManager::class.java)
                    nm.notify(NOTIF_ID, notification("جاري تحميل ${s.first} ملف • ${s.second}%", s.second))
                    delay(1500)
                }
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL, "التحميلات", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun notification(text: String, pct: Int) =
        NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("المصري سات")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(100, pct, false)
            .also { b ->
                packageManager.getLaunchIntentForPackage(packageName)?.let {
                    b.setContentIntent(PendingIntent.getActivity(this, 0, it, PendingIntent.FLAG_IMMUTABLE))
                }
            }
            .build()
}
