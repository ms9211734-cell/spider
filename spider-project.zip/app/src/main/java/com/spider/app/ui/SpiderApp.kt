package com.spider.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color

@Composable
fun SpiderApp(vm: SpiderViewModel) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Gold, onPrimary = Navy, background = Navy, surface = Navy, secondaryContainer = Color(0xFF2B2200), onSecondaryContainer = Gold)) {
        Surface(Modifier.fillMaxSize()) {
            BackHandler(enabled = vm.screen is Screen.Player || vm.screen is Screen.SeriesDetail) {
                vm.back()
            }
            when (val s = vm.screen) {
                is Screen.Login -> LoginScreen(vm)
                is Screen.Home -> HomeScreen(vm)
                is Screen.SeriesDetail -> SeriesScreen(vm, s.series)
                is Screen.Player -> PlayerScreen(s.url, s.title, s.fallback)
            }
        }
    }
}
