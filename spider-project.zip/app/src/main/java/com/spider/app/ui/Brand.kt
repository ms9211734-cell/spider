package com.spider.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Gold = Color(0xFFF5B700)
val GoldDeep = Color(0xFFC98A00)
val GoldLight = Color(0xFFFFD84D)
val Navy = Color(0xFF050B1E)
val NavyLight = Color(0xFF0E1D45)

/** رمز طبق الدش بإشارات ذهبية. pulse من 0 إلى 1 لنبض الإشارات */
@Composable
fun DishMark(modifier: Modifier = Modifier, pulse: Float = 1f) {
    Canvas(modifier) {
        val s = size.minDimension / 100f
        fun o(x: Float, y: Float) = Offset(x * s, y * s)
        val gold = Brush.linearGradient(listOf(GoldLight, Gold, GoldDeep), start = o(10f, 20f), end = o(70f, 90f))

        // الطبق
        val bowl = Path().apply {
            moveTo(18f * s, 40f * s)
            quadraticBezierTo(20f * s, 82f * s, 62f * s, 82f * s)
            quadraticBezierTo(38f * s, 66f * s, 18f * s, 40f * s)
            close()
        }
        drawPath(bowl, gold)

        // الذراع والقاعدة
        drawLine(Gold, o(35f, 67f), o(64f, 36f), strokeWidth = 3f * s, cap = StrokeCap.Round)
        drawLine(Gold, o(48f, 78f), o(48f, 90f), strokeWidth = 4f * s, cap = StrokeCap.Round)
        drawRoundRect(gold, topLeft = o(34f, 90f), size = Size(28f * s, 4f * s), cornerRadius = CornerRadius(2f * s))

        // رأس الاستقبال
        drawCircle(GoldLight, 5f * s, o(68f, 32f))

        // موجات الإشارة
        listOf(13f, 21f, 29f).forEachIndexed { i, r ->
            val a = (0.35f + 0.65f * pulse) * (1f - i * 0.25f)
            drawArc(
                Gold.copy(alpha = a), startAngle = -90f, sweepAngle = 90f, useCenter = false,
                topLeft = o(68f - r, 32f - r), size = Size(2f * r * s, 2f * r * s),
                style = Stroke(width = 3f * s, cap = StrokeCap.Round)
            )
        }
    }
}

/** اللوجو الكامل: الرمز + الاسم */
@Composable
fun BrandLogo(pulse: Float = 1f) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        DishMark(Modifier.size(120.dp), pulse)
        Spacer(Modifier.height(6.dp))
        Text(
            "المصري سات",
            style = TextStyle(
                brush = Brush.horizontalGradient(listOf(GoldLight, Gold, GoldDeep)),
                fontSize = 40.sp, fontWeight = FontWeight.Black
            )
        )
        Text(
            "EL MASRY SAT", color = Color.White.copy(alpha = 0.7f),
            fontSize = 12.sp, letterSpacing = 6.sp, fontWeight = FontWeight.Medium
        )
    }
}
