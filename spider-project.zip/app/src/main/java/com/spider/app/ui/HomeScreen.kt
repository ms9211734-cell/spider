package com.spider.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.spider.app.data.DlStatus
import com.spider.app.data.DownloadUi

@Composable
fun HomeScreen(vm: SpiderViewModel) {
    val ctx = LocalContext.current
    val version = remember {
        try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
    }
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            DishMark(Modifier.size(36.dp))
            Column(Modifier.weight(1f).padding(start = 10.dp)) {
                Text(
                    "المصري سات", style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Text("v$version", fontSize = 10.sp, color = Color.White.copy(alpha = 0.4f))
            }
            TextButton(onClick = { vm.logout() }) { Text("خروج") }
        }

        if (vm.offline) {
            OfflineBanner(vm)
            DownloadsList(vm)
        } else {
            TabRow(selectedTabIndex = vm.tab) {
                listOf("مباشر", "أفلام", "مسلسلات", "⬇ تحميلات").forEachIndexed { i, t ->
                    Tab(selected = vm.tab == i, onClick = { vm.loadTab(i) }, text = { Text(t, maxLines = 1) })
                }
            }
            if (vm.tab != 3) {
                OutlinedTextField(
                    value = vm.query, onValueChange = { vm.query = it }, singleLine = true,
                    label = { Text("بحث") },
                    modifier = Modifier.fillMaxWidth().padding(8.dp)
                )
                val cats = when (vm.tab) {
                    0 -> vm.liveCats
                    1 -> vm.vodCats
                    else -> vm.seriesCats
                }
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        FilterChip(
                            selected = vm.selectedCat == null, onClick = { vm.selectedCat = null },
                            label = { Text("الكل") }
                        )
                    }
                    items(cats) { c ->
                        FilterChip(
                            selected = vm.selectedCat == c.id, onClick = { vm.selectedCat = c.id },
                            label = { Text(c.name) }
                        )
                    }
                }
                if (vm.loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))
                vm.error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(8.dp)) }
                Spacer(Modifier.height(8.dp))
            }
            when (vm.tab) {
                0 -> LiveList(vm)
                1 -> MovieGrid(vm)
                2 -> SeriesGrid(vm)
                else -> DownloadsList(vm)
            }
        }
    }
}

@Composable
private fun OfflineBanner(vm: SpiderViewModel) {
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = 0.07f)).padding(14.dp)
    ) {
        Text("📴 وضع بدون إنترنت", fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
        Text(
            "بتشاهد الملفات اللي حمّلتها بس. اتصل بالإنترنت وارجع للقنوات والأفلام.",
            fontSize = 12.sp, color = Color.White.copy(alpha = 0.6f), modifier = Modifier.padding(top = 4.dp)
        )
        if (vm.loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))
        vm.error?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) }
        TextButton(onClick = { vm.retryOnline() }, enabled = !vm.loading) { Text("🔄 إعادة الاتصال") }
    }
}

@Composable
private fun LiveList(vm: SpiderViewModel) {
    val list = remember(vm.liveStreams, vm.selectedCat, vm.query) {
        vm.liveStreams.filter {
            (vm.selectedCat == null || it.categoryId == vm.selectedCat) && it.name.contains(vm.query, true)
        }
    }
    LazyColumn(Modifier.fillMaxSize()) {
        items(list) { s ->
            Row(
                Modifier.fillMaxWidth().clickable { vm.playLive(s) }.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AsyncImage(model = s.icon, contentDescription = null, modifier = Modifier.size(44.dp))
                Spacer(Modifier.width(12.dp))
                Text(s.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun MovieGrid(vm: SpiderViewModel) {
    val list = remember(vm.vodStreams, vm.selectedCat, vm.query) {
        vm.vodStreams.filter {
            (vm.selectedCat == null || it.categoryId == vm.selectedCat) && it.name.contains(vm.query, true)
        }
    }
    LazyVerticalGrid(
        columns = GridCells.Adaptive(120.dp),
        contentPadding = PaddingValues(8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(list) { m ->
            Poster(m.name, m.icon, vm.statusOf("m${m.streamId}"), { vm.downloadMovie(m) }) { vm.playMovie(m) }
        }
    }
}

@Composable
private fun SeriesGrid(vm: SpiderViewModel) {
    val list = remember(vm.seriesList, vm.selectedCat, vm.query) {
        vm.seriesList.filter {
            (vm.selectedCat == null || it.categoryId == vm.selectedCat) && it.name.contains(vm.query, true)
        }
    }
    LazyVerticalGrid(
        columns = GridCells.Adaptive(120.dp),
        contentPadding = PaddingValues(8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(list) { s -> Poster(s.name, s.cover, null, null) { vm.openSeries(s) } }
    }
}

@Composable
private fun Poster(
    title: String,
    image: String?,
    state: DlStatus?,
    onDownload: (() -> Unit)?,
    onClick: () -> Unit
) {
    Column(Modifier.clickable(onClick = onClick)) {
        Box {
            AsyncImage(
                model = image, contentDescription = title, contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxWidth().aspectRatio(2f / 3f)
                    .clip(RoundedCornerShape(8.dp)).background(Color(0xFF16203F))
            )
            if (onDownload != null) {
                DownloadBadge(state, onDownload, Modifier.align(Alignment.TopEnd).padding(6.dp))
            }
        }
        Text(
            title, maxLines = 2, overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp)
        )
    }
}

/** زرار التحميل: ⬇ جاهز للتحميل، ⏳ جاري، ✓ تم، ⚠ فشل */
@Composable
fun DownloadBadge(state: DlStatus?, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val (icon, bg) = when (state) {
        null -> "⬇" to Color(0xCC000000)
        DlStatus.DONE -> "✓" to Color(0xFF2E7D32)
        DlStatus.FAILED -> "⚠" to Color(0xFFB71C1C)
        else -> "⏳" to Color(0xFF1565C0)
    }
    Box(
        modifier.size(34.dp).clip(CircleShape).background(bg).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(icon, color = Color.White, fontSize = 15.sp)
    }
}

@Composable
private fun DownloadsList(vm: SpiderViewModel) {
    var confirm by remember { mutableStateOf<DownloadUi?>(null) }

    if (vm.downloads.isEmpty()) {
        Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Text(
                "لا توجد تحميلات بعد.\nاضغط ⬇ على أي فيلم أو حلقة لتحميلها ومشاهدتها بدون إنترنت.",
                textAlign = TextAlign.Center, color = Color.White.copy(alpha = 0.6f)
            )
        }
    } else {
        LazyColumn(Modifier.fillMaxSize()) {
            items(vm.downloads) { d ->
                DownloadRow(d, onPlay = { vm.playDownload(d) }, onDelete = { confirm = d })
            }
        }
    }

    confirm?.let { d ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text("حذف التحميل؟") },
            text = { Text(d.item.title) },
            confirmButton = {
                TextButton(onClick = { vm.deleteDownload(d.item.key); confirm = null }) { Text("حذف") }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("إلغاء") } }
        )
    }
}

@Composable
private fun DownloadRow(d: DownloadUi, onPlay: () -> Unit, onDelete: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onPlay).padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(
            model = d.item.poster, contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.size(width = 52.dp, height = 74.dp)
                .clip(RoundedCornerShape(8.dp)).background(Color(0xFF16203F))
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(d.item.title, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(6.dp))
            when (d.status) {
                DlStatus.DONE -> Text(
                    "✅ جاهز للمشاهدة • ${fmtSize(maxOf(d.total, d.done))}",
                    fontSize = 12.sp, color = Color(0xFF81C784)
                )
                DlStatus.FAILED -> Text(
                    "⚠️ فشل التحميل ${d.error ?: ""}\nاضغط هنا لإعادة المحاولة من حيث توقف",
                    fontSize = 12.sp, color = Color(0xFFFF8A80)
                )
                else -> {
                    if (d.total > 0) {
                        LinearProgressIndicator(progress = { d.percent / 100f }, modifier = Modifier.fillMaxWidth())
                    } else {
                        LinearProgressIndicator(Modifier.fillMaxWidth())
                    }
                    val txt = when (d.status) {
                        DlStatus.PENDING -> "في الانتظار (بيتحمّل ملف واحد في المرة)"
                        DlStatus.PAUSED -> "⏳ الاتصال انقطع — هيكمّل لوحده${d.error?.let { " ($it)" } ?: ""}"
                        else -> if (d.total > 0) "${d.percent}% • ${fmtSize(d.done)} / ${fmtSize(d.total)}" else fmtSize(d.done)
                    }
                    Text(txt, fontSize = 12.sp, color = Color.White.copy(alpha = 0.6f), modifier = Modifier.padding(top = 4.dp))
                }
            }
        }
        Text("🗑", fontSize = 20.sp, modifier = Modifier.clickable(onClick = onDelete).padding(10.dp))
    }
}

private fun fmtSize(b: Long): String = when {
    b >= 1_073_741_824L -> String.format(java.util.Locale.US, "%.2f GB", b / 1_073_741_824.0)
    b >= 1_048_576L -> String.format(java.util.Locale.US, "%.0f MB", b / 1_048_576.0)
    else -> String.format(java.util.Locale.US, "%d KB", b / 1024)
}
