package com.spider.app.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.ui.res.painterResource
import com.spider.app.R
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

@Composable
fun HomeScreen(vm: SpiderViewModel) {
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            DishMark(Modifier.size(36.dp))
            Text("المصري سات", style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f).padding(start = 10.dp))
            TextButton(onClick = { vm.logout() }) { Text("خروج") }
        }
        TabRow(selectedTabIndex = vm.tab) {
            listOf("مباشر", "أفلام", "مسلسلات").forEachIndexed { i, t ->
                Tab(selected = vm.tab == i, onClick = { vm.loadTab(i) }, text = { Text(t) })
            }
        }
        OutlinedTextField(
            value = vm.query, onValueChange = { vm.query = it }, singleLine = true,
            label = { Text("بحث") },
            modifier = Modifier.fillMaxWidth().padding(8.dp)
        )
        val cats = when (vm.tab) {
            0 -> vm.liveCats
            1 -> vm.vodCats
            else -> vm.seriesCats
        }
        LazyRow(
            contentPadding = PaddingValues(horizontal = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                FilterChip(selected = vm.selectedCat == null, onClick = { vm.selectedCat = null }, label = { Text("الكل") })
            }
            items(cats) { c ->
                FilterChip(selected = vm.selectedCat == c.id, onClick = { vm.selectedCat = c.id }, label = { Text(c.name) })
            }
        }
        if (vm.loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))
        vm.error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(8.dp)) }
        Spacer(Modifier.height(8.dp))
        when (vm.tab) {
            0 -> LiveList(vm)
            1 -> MovieGrid(vm)
            else -> SeriesGrid(vm)
        }
    }
}

@Composable
private fun LiveList(vm: SpiderViewModel) {
    val list = remember(vm.liveStreams, vm.selectedCat, vm.query) {
        vm.liveStreams.filter {
            (vm.selectedCat == null || it.categoryId == vm.selectedCat) && it.name.contains(vm.query, true)
        }
    }
    LazyColumn(Modifier.fillMaxSize()) {
        items(list) { s ->
            Row(
                Modifier.fillMaxWidth().clickable { vm.playLive(s) }.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AsyncImage(model = s.icon, contentDescription = null, modifier = Modifier.size(44.dp))
                Spacer(Modifier.width(12.dp))
                Text(s.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun MovieGrid(vm: SpiderViewModel) {
    val list = remember(vm.vodStreams, vm.selectedCat, vm.query) {
        vm.vodStreams.filter {
            (vm.selectedCat == null || it.categoryId == vm.selectedCat) && it.name.contains(vm.query, true)
        }
    }
    LazyVerticalGrid(
        columns = GridCells.Adaptive(120.dp),
        contentPadding = PaddingValues(8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(list) { m -> Poster(m.name, m.icon) { vm.playMovie(m) } }
    }
}

@Composable
private fun SeriesGrid(vm: SpiderViewModel) {
    val list = remember(vm.seriesList, vm.selectedCat, vm.query) {
        vm.seriesList.filter {
            (vm.selectedCat == null || it.categoryId == vm.selectedCat) && it.name.contains(vm.query, true)
        }
    }
    LazyVerticalGrid(
        columns = GridCells.Adaptive(120.dp),
        contentPadding = PaddingValues(8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(list) { s -> Poster(s.name, s.cover) { vm.openSeries(s) } }
    }
}

@Composable
private fun Poster(title: String, image: String?, onClick: () -> Unit) {
    Column(Modifier.clickable(onClick = onClick)) {
        AsyncImage(
            model = image, contentDescription = title, contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxWidth().aspectRatio(2f / 3f)
                .clip(RoundedCornerShape(8.dp)).background(Color(0xFF222222))
        )
        Text(
            title, maxLines = 2, overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp)
        )
    }
}
