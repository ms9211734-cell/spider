package com.spider.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView

@Composable
fun PlayerScreen(url: String, title: String, fallbackUrl: String? = null) {
    val ctx = LocalContext.current
    var err by remember(url) { mutableStateOf<String?>(null) }
    var triedFallback by remember(url) { mutableStateOf(false) }

    val exo = remember(url) {
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent("VLC/3.0.20 LibVLC/3.0.20")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(30_000)
        ExoPlayer.Builder(ctx)
            .setMediaSourceFactory(DefaultMediaSourceFactory(DefaultDataSource.Factory(ctx, http)))
            .build()
    }

    DisposableEffect(exo) {
        val listener = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                val code = (error.cause as? HttpDataSource.InvalidResponseCodeException)?.responseCode
                val ioProblem = code != null ||
                    error.errorCode == PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS ||
                    error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED
                if (fallbackUrl != null && !triedFallback && ioProblem) {
                    // جرّب صيغة البث التانية (ts بدل m3u8)
                    triedFallback = true
                    exo.setMediaItem(MediaItem.fromUri(fallbackUrl))
                    exo.prepare()
                    exo.playWhenReady = true
                    return
                }
                err = "تعذّر التشغيل " + (code?.let { "(HTTP $it)" } ?: "(${error.errorCodeName})")
            }
        }
        exo.addListener(listener)
        exo.setMediaItem(MediaItem.fromUri(url))
        exo.prepare()
        exo.playWhenReady = true
        onDispose {
            exo.removeListener(listener)
            exo.release()
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { c ->
                PlayerView(c).apply {
                    player = exo
                    useController = true
                    keepScreenOn = true
                }
            },
            modifier = Modifier.fillMaxSize()
        )
        Text(title, color = Color.White, modifier = Modifier.align(Alignment.TopStart).padding(12.dp))
        err?.let { msg ->
            Column(Modifier.align(Alignment.Center).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(msg, color = Color.White, fontSize = 16.sp)
                Text(
                    "🔄 إعادة المحاولة", color = Color(0xFFF5B700), fontSize = 16.sp,
                    modifier = Modifier.padding(top = 14.dp).clickable {
                        err = null
                        triedFallback = false
                        exo.setMediaItem(MediaItem.fromUri(url))
                        exo.prepare()
                        exo.playWhenReady = true
                    }.padding(10.dp)
                )
            }
        }
    }
}
