package com.spider.app.data.remote

import com.spider.app.data.model.*
import retrofit2.http.GET
import retrofit2.http.Query

interface XtreamApi {
    @GET("player_api.php")
    suspend fun login(
        @Query("username") user: String,
        @Query("password") pass: String
    ): LoginResponse

    @GET("player_api.php")
    suspend fun liveCategories(
        @Query("username") user: String, @Query("password") pass: String,
        @Query("action") action: String = "get_live_categories"
    ): List<Category>

    @GET("player_api.php")
    suspend fun liveStreams(
        @Query("username") user: String, @Query("password") pass: String,
        @Query("category_id") categoryId: String? = null,
        @Query("action") action: String = "get_live_streams"
    ): List<LiveStream>

    @GET("player_api.php")
    suspend fun vodCategories(
        @Query("username") user: String, @Query("password") pass: String,
        @Query("action") action: String = "get_vod_categories"
    ): List<Category>

    @GET("player_api.php")
    suspend fun vodStreams(
        @Query("username") user: String, @Query("password") pass: String,
        @Query("category_id") categoryId: String? = null,
        @Query("action") action: String = "get_vod_streams"
    ): List<VodStream>

    @GET("player_api.php")
    suspend fun seriesCategories(
        @Query("username") user: String, @Query("password") pass: String,
        @Query("action") action: String = "get_series_categories"
    ): List<Category>

    @GET("player_api.php")
    suspend fun seriesList(
        @Query("username") user: String, @Query("password") pass: String,
        @Query("category_id") categoryId: String? = null,
        @Query("action") action: String = "get_series"
    ): List<Series>

    @GET("player_api.php")
    suspend fun seriesInfo(
        @Query("username") user: String, @Query("password") pass: String,
        @Query("series_id") seriesId: Int,
        @Query("action") action: String = "get_series_info"
    ): SeriesInfo

    @GET("player_api.php")
    suspend fun shortEpg(
        @Query("username") user: String, @Query("password") pass: String,
        @Query("stream_id") streamId: Int,
        @Query("limit") limit: Int = 4,
        @Query("action") action: String = "get_short_epg"
    ): EpgResponse
}
