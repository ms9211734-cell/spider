package com.spider.app.data.remote

import retrofit2.converter.kotlinx.serialization.asConverterFactory
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import java.util.concurrent.TimeUnit

object ApiFactory {
    private val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
        coerceInputValues = true   // سيرفرات Xtream بترجع أنواع بيانات مش ثابتة
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)   // قوائم القنوات ممكن تبقى ضخمة
        .build()

    /** السيرفر بيتحدد من العميل وقت الدخول، فبنبني Retrofit ديناميكياً */
    fun create(serverUrl: String): XtreamApi {
        val base = serverUrl.trim().trimEnd('/') + "/"
        return Retrofit.Builder()
            .baseUrl(base)
            .client(client)
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()
            .create(XtreamApi::class.java)
    }
}
