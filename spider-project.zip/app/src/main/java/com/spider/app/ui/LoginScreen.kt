package com.spider.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp

@Composable
fun LoginScreen(vm: SpiderViewModel) {
    var server by remember { mutableStateOf(vm.saved?.first ?: "") }
    var user by remember { mutableStateOf(vm.saved?.second ?: "") }
    var pass by remember { mutableStateOf(vm.saved?.third ?: "") }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("🕷️ Spider", style = MaterialTheme.typography.displaySmall)
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(
            value = server, onValueChange = { server = it }, singleLine = true,
            label = { Text("رابط السيرفر (http://host:port)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
            modifier = Modifier.fillMaxWidth().widthIn(max = 480.dp)
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = user, onValueChange = { user = it }, singleLine = true,
            label = { Text("اسم المستخدم") },
            modifier = Modifier.fillMaxWidth().widthIn(max = 480.dp)
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = pass, onValueChange = { pass = it }, singleLine = true,
            label = { Text("كلمة المرور") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth().widthIn(max = 480.dp)
        )
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { vm.login(server, user, pass) },
            enabled = !vm.loading,
            modifier = Modifier.fillMaxWidth().widthIn(max = 480.dp)
        ) { Text(if (vm.loading) "جاري الدخول..." else "دخول") }
        vm.error?.let {
            Spacer(Modifier.height(12.dp))
            Text(it, color = MaterialTheme.colorScheme.error)
        }
    }
}
