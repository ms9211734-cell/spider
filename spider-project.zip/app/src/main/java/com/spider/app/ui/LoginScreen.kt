package com.spider.app.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun LoginScreen(vm: SpiderViewModel) {
    var server by remember { mutableStateOf(vm.saved?.first ?: "") }
    var user by remember { mutableStateOf(vm.saved?.second ?: "") }
    var pass by remember { mutableStateOf(vm.saved?.third ?: "") }
    var showPass by remember { mutableStateOf(false) }

    val inf = rememberInfiniteTransition(label = "brand")
    val bob by inf.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(2800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "bob"
    )
    val pulse by inf.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(1600), RepeatMode.Reverse),
        label = "pulse"
    )
    val shine by inf.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(2400, easing = LinearEasing), RepeatMode.Restart),
        label = "shine"
    )

    val logoScale = remember { Animatable(0.8f) }
    val logoAlpha = remember { Animatable(0f) }
    val cardIn = remember { Animatable(0f) }
    LaunchedEffect(Unit) { logoAlpha.animateTo(1f, tween(700)) }
    LaunchedEffect(Unit) { logoScale.animateTo(1f, spring(dampingRatio = 0.55f, stiffness = 120f)) }
    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(350)
        cardIn.animateTo(1f, tween(800, easing = FastOutSlowInEasing))
    }

    Box(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Navy, NavyLight, Navy)))
    ) {
        SkyBackground(Modifier.fillMaxSize())

        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(40.dp))

            Box(
                Modifier.graphicsLayer {
                    translationY = bob * 10.dp.toPx()
                    scaleX = logoScale.value
                    scaleY = logoScale.value
                    alpha = logoAlpha.value
                },
                contentAlignment = Alignment.Center
            ) {
                Canvas(Modifier.size(260.dp)) {
                    val rad = size.width * 0.5f
                    drawCircle(
                        Brush.radialGradient(
                            listOf(Gold.copy(alpha = 0.18f + 0.12f * pulse), Color.Transparent),
                            center = center, radius = rad
                        ),
                        radius = rad, center = center
                    )
                }
                BrandLogo(pulse)
            }

            Spacer(Modifier.height(22.dp))

            Column(
                Modifier
                    .graphicsLayer {
                        alpha = cardIn.value
                        translationY = (1f - cardIn.value) * 70f
                    }
                    .widthIn(max = 440.dp).fillMaxWidth()
                    .clip(RoundedCornerShape(26.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(Color.White.copy(alpha = 0.09f), Color.White.copy(alpha = 0.03f))
                        )
                    )
                    .border(
                        1.dp,
                        Brush.verticalGradient(listOf(Gold.copy(alpha = 0.55f), Color.White.copy(alpha = 0.08f))),
                        RoundedCornerShape(26.dp)
                    )
                    .padding(20.dp)
            ) {
                Text("أهلاً بيك 👋", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text(
                    "سجّل دخولك ببيانات اشتراكك", color = Color.White.copy(alpha = 0.55f),
                    fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp, bottom = 18.dp)
                )

                BrandField(
                    value = server, onChange = { server = it }, label = "رابط السيرفر", icon = "🌐",
                    keyboardType = KeyboardType.Uri, ime = ImeAction.Next
                )
                Spacer(Modifier.height(12.dp))
                BrandField(
                    value = user, onChange = { user = it }, label = "اسم المستخدم", icon = "👤",
                    ime = ImeAction.Next
                )
                Spacer(Modifier.height(12.dp))
                BrandField(
                    value = pass, onChange = { pass = it }, label = "كلمة المرور", icon = "🔒",
                    keyboardType = KeyboardType.Password, ime = ImeAction.Done,
                    onDone = { vm.login(server, user, pass) },
                    visual = if (showPass) VisualTransformation.None else PasswordVisualTransformation(),
                    trailing = {
                        Text(
                            if (showPass) "🙈" else "👁",
                            modifier = Modifier.clickable { showPass = !showPass }.padding(8.dp)
                        )
                    }
                )

                vm.error?.let {
                    Text(
                        "⚠️  $it", color = Color(0xFFFF8A80), fontSize = 13.sp,
                        modifier = Modifier.padding(top = 14.dp)
                    )
                }

                Spacer(Modifier.height(20.dp))

                val sx = -500f + 1700f * shine
                Box(
                    Modifier.fillMaxWidth().height(56.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(GoldDeep, Gold, GoldLight, Gold, GoldDeep),
                                start = Offset(sx, 0f), end = Offset(sx + 600f, 0f)
                            )
                        )
                        .clickable(enabled = !vm.loading) { vm.login(server, user, pass) },
                    contentAlignment = Alignment.Center
                ) {
                    if (vm.loading) {
                        CircularProgressIndicator(Modifier.size(24.dp), color = Navy, strokeWidth = 2.5.dp)
                    } else {
                        Text("دخول", color = Navy, fontSize = 18.sp, fontWeight = FontWeight.Black)
                    }
                }
            }

            Text(
                "المصري سات مشغّل فقط ولا يحتوي على أي قنوات أو محتوى.\nأدخل بيانات اشتراكك الخاص من مزوّدك.",
                color = Color.White.copy(alpha = 0.35f), fontSize = 11.sp, textAlign = TextAlign.Center,
                modifier = Modifier.padding(vertical = 22.dp)
            )
        }
    }
}

@Composable
private fun BrandField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    icon: String,
    keyboardType: KeyboardType = KeyboardType.Text,
    ime: ImeAction = ImeAction.Next,
    onDone: () -> Unit = {},
    visual: VisualTransformation = VisualTransformation.None,
    trailing: @Composable (() -> Unit)? = null
) {
    OutlinedTextField(
        value = value, onValueChange = onChange, singleLine = true,
        label = { Text(label) },
        leadingIcon = { Text(icon, modifier = Modifier.padding(start = 8.dp)) },
        trailingIcon = trailing,
        visualTransformation = visual,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType, imeAction = ime),
        keyboardActions = KeyboardActions(onDone = { onDone() }),
        shape = RoundedCornerShape(14.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Gold,
            unfocusedBorderColor = Color.White.copy(alpha = 0.18f),
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White,
            focusedContainerColor = Color.White.copy(alpha = 0.04f),
            unfocusedContainerColor = Color.Transparent,
            cursorColor = Gold,
            focusedLabelColor = Gold,
            unfocusedLabelColor = Color.White.copy(alpha = 0.6f)
        ),
        modifier = Modifier.fillMaxWidth()
    )
}

/** سماء بنجوم ومدارات ذهبية خفيفة */
@Composable
private fun SkyBackground(modifier: Modifier) {
    Canvas(modifier) {
        val rnd = kotlin.random.Random(7)
        repeat(70) {
            val x = rnd.nextFloat() * size.width
            val y = rnd.nextFloat() * size.height
            val r = 0.6f + rnd.nextFloat() * 1.6f
            drawCircle(Color.White.copy(alpha = 0.15f + rnd.nextFloat() * 0.45f), r, Offset(x, y))
        }
        val c = Offset(size.width * 0.5f, size.height * 0.2f)
        for (i in 1..4) {
            val rx = size.width * (0.35f + i * 0.22f)
            drawOval(
                Gold.copy(alpha = 0.08f),
                topLeft = Offset(c.x - rx, c.y - rx * 0.32f),
                size = Size(rx * 2, rx * 0.64f),
                style = Stroke(width = 1.5f)
            )
        }
    }
}
