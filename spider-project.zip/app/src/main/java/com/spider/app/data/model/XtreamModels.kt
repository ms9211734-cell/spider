package com.spider.app.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class LoginResponse(
    @SerialName("user_info") val userInfo: UserInfo? = null,
    @SerialName("server_info") val serverInfo: ServerInfo? = null
)

@Serializable
data class UserInfo(
    val username: String? = null,
    val auth: String? = null,          // "1" = نجح الدخول
    val status: String? = null,        // Active / Expired
    @SerialName("exp_date") val expDate: String? = null,
    @SerialName("max_connections") val maxConnections: String? = null
)

@Serializable
data class ServerInfo(
    val url: String? = null,
    val port: String? = null,
    @SerialName("server_protocol") val protocol: String? = null
)

@Serializable
data class Category(
    @SerialName("category_id") val id: String = "",
    @SerialName("category_name") val name: String = ""
)

@Serializable
data class LiveStream(
    @SerialName("stream_id") val streamId: Int,
    val name: String = "",
    @SerialName("stream_icon") val icon: String? = null,
    @SerialName("epg_channel_id") val epgId: String? = null,
    @SerialName("category_id") val categoryId: String? = null
)

@Serializable
data class VodStream(
    @SerialName("stream_id") val streamId: Int,
    val name: String = "",
    @SerialName("stream_icon") val icon: String? = null,
    val rating: String? = null,
    @SerialName("container_extension") val ext: String? = "mp4",
    @SerialName("category_id") val categoryId: String? = null
)

@Serializable
data class Series(
    @SerialName("series_id") val seriesId: Int,
    val name: String = "",
    val cover: String? = null,
    val plot: String? = null,
    val rating: String? = null,
    @SerialName("category_id") val categoryId: String? = null
)

@Serializable
data class SeriesInfo(
    val episodes: Map<String, List<Episode>> = emptyMap() // المفتاح = رقم الموسم
)

@Serializable
data class Episode(
    val id: String = "",
    @SerialName("episode_num") val num: String? = null,
    val title: String? = null,
    @SerialName("container_extension") val ext: String? = "mp4"
)

@Serializable
data class EpgResponse(
    @SerialName("epg_listings") val listings: List<EpgItem> = emptyList()
)

@Serializable
data class EpgItem(
    val title: String? = null,        // Base64
    val description: String? = null,  // Base64
    @SerialName("start_timestamp") val start: String? = null,
    @SerialName("stop_timestamp") val stop: String? = null
)
