package com.spider.app.data

import android.content.Context

class SessionStore(ctx: Context) {
    private val p = ctx.getSharedPreferences("spider", Context.MODE_PRIVATE)

    fun save(server: String, user: String, pass: String) {
        p.edit().putString("server", server).putString("user", user).putString("pass", pass).apply()
    }

    fun load(): Triple<String, String, String>? {
        val s = p.getString("server", null) ?: return null
        val u = p.getString("user", null) ?: return null
        val pw = p.getString("pass", null) ?: return null
        return Triple(s, u, pw)
    }

    fun clear() = p.edit().clear().apply()
}
