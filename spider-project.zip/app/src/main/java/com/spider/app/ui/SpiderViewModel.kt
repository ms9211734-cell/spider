package com.spider.app.ui

import android.app.Application
import android.net.Uri
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.spider.app.data.DlStatus
import com.spider.app.data.DownloadUi
import com.spider.app.data.DownloadsStore
import com.spider.app.data.SessionStore
import com.spider.app.data.model.*
import com.spider.app.data.repo.XtreamRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

sealed interface Screen {
    data object Login : Screen
    data object Home : Screen
    data class SeriesDetail(val series: Series) : Screen
    data class Player(
        val url: String,
        val title: String,
        val fallback: String? = null,
        val remote: Boolean = true
    ) : Screen
}

class SpiderViewModel(app: Application) : AndroidViewModel(app) {
    private val store = SessionStore(app)
    private val dl = DownloadsStore(app)
    private var repo: XtreamRepository? = null
    private var returnTo: Screen = Screen.Home

    var screen by mutableStateOf<Screen>(Screen.Login)
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var offline by mutableStateOf(false)
    val saved = store.load()

    var tab by mutableIntStateOf(0)
    var query by mutableStateOf("")
    var selectedCat by mutableStateOf<String?>(null)

    var liveCats by mutableStateOf<List<Category>>(emptyList())
    var liveStreams by mutableStateOf<List<LiveStream>>(emptyList())
    var vodCats by mutableStateOf<List<Category>>(emptyList())
    var vodStreams by mutableStateOf<List<VodStream>>(emptyList())
    var seriesCats by mutableStateOf<List<Category>>(emptyList())
    var seriesList by mutableStateOf<List<Series>>(emptyList())
    var episodes by mutableStateOf<Map<String, List<Episode>>>(emptyMap())

    var downloads by mutableStateOf<List<DownloadUi>>(emptyList())

    init {
        // متابعة حالة التحميلات
        viewModelScope.launch {
            while (true) {
                val fresh = withContext(Dispatchers.IO) { dl.refresh() }
                if (fresh != downloads) downloads = fresh
                delay(1500)
            }
        }
        saved?.let { login(it.first, it.second, it.third, auto = true) }
    }

    private fun toast(msg: String) =
        Toast.makeText(getApplication<Application>(), msg, Toast.LENGTH_SHORT).show()

    fun login(server: String, user: String, pass: String, auto: Boolean = false) {
        var s = server.trim()
        if (s.isEmpty() || user.isBlank() || pass.isBlank()) {
            error = "اكتب كل البيانات"
            return
        }
        if (!s.startsWith("http")) s = "http://$s"
        loading = true
        error = null
        viewModelScope.launch {
            val r = try {
                XtreamRepository(s, user.trim(), pass.trim())
            } catch (e: Exception) {
                error = "رابط السيرفر غير صحيح"
                loading = false
                return@launch
            }
            r.login()
                .onSuccess {
                    repo = r
                    offline = false
                    store.save(s, user.trim(), pass.trim())
                    screen = Screen.Home
                    loadTab(0)
                }
                .onFailure {
                    if (auto && it is java.io.IOException && dl.items().isNotEmpty()) {
                        openOffline()
                    } else {
                        error = it.message ?: "فشل الاتصال بالسيرفر"
                    }
                }
            loading = false
        }
    }

    /** المشاهدة بدون إنترنت: التحميلات فقط */
    fun openOffline() {
        offline = true
        tab = 3
        error = null
        screen = Screen.Home
    }

    fun retryOnline() {
        val s = saved ?: store.load()
        if (s == null) {
            offline = false
            screen = Screen.Login
        } else {
            login(s.first, s.second, s.third)
        }
    }

    fun loadTab(i: Int) {
        tab = i
        selectedCat = null
        query = ""
        error = null
        if (i == 3) return
        val r = repo ?: return
        viewModelScope.launch {
            loading = true
            when (i) {
                0 -> if (liveStreams.isEmpty()) {
                    r.liveCategories().onSuccess { liveCats = it }
                    r.liveStreams().onSuccess { liveStreams = it }.onFailure { error = it.message }
                }
                1 -> if (vodStreams.isEmpty()) {
                    r.vodCategories().onSuccess { vodCats = it }
                    r.vodStreams().onSuccess { vodStreams = it }.onFailure { error = it.message }
                }
                else -> if (seriesList.isEmpty()) {
                    r.seriesCategories().onSuccess { seriesCats = it }
                    r.seriesList().onSuccess { seriesList = it }.onFailure { error = it.message }
                }
            }
            loading = false
        }
    }

    fun openSeries(s: Series) {
        screen = Screen.SeriesDetail(s)
        episodes = emptyMap()
        error = null
        val r = repo ?: return
        viewModelScope.launch {
            loading = true
            r.seriesInfo(s.seriesId).onSuccess { episodes = it.episodes }.onFailure { error = it.message }
            loading = false
        }
    }

    private fun play(url: String, title: String, fallback: String? = null, remote: Boolean = true) {
        if (remote) dl.suspendAll() // وقف التحميل مؤقتاً أثناء المشاهدة
        returnTo = screen
        screen = Screen.Player(url, title, fallback, remote)
    }

    fun playLive(s: LiveStream) =
        repo?.let { play(it.urls.live(s.streamId), s.name, it.urls.live(s.streamId, "ts")) }
    fun playMovie(m: VodStream) = repo?.let { play(it.urls.movie(m.streamId, m.ext), m.name) }
    fun playEpisode(e: Episode, seriesName: String) =
        repo?.let { play(it.urls.episode(e.id, e.ext), "$seriesName - ${e.title ?: ""}") }

    // ---------- التحميلات ----------
    fun statusOf(key: String): DlStatus? = downloads.firstOrNull { it.item.key == key }?.status

    private fun startDownload(key: String, title: String, poster: String?, url: String, ext: String) {
        when (statusOf(key)) {
            DlStatus.DONE -> { toast("موجود بالفعل في التحميلات"); return }
            DlStatus.RUNNING, DlStatus.PENDING, DlStatus.PAUSED -> { toast("جاري التحميل بالفعل"); return }
            DlStatus.FAILED -> {
                dl.retry(key)
                toast("إعادة المحاولة...")
                viewModelScope.launch { downloads = withContext(Dispatchers.IO) { dl.refresh() } }
                return
            }
            null -> {}
        }
        dl.enqueue(key, title, poster, url, ext)
        toast("بدأ التحميل ⬇ تابعه من تبويب التحميلات")
        viewModelScope.launch { downloads = withContext(Dispatchers.IO) { dl.refresh() } }
    }

    fun downloadMovie(m: VodStream) {
        val r = repo ?: return
        val ext = m.ext ?: "mp4"
        startDownload("m${m.streamId}", m.name, m.icon, r.urls.movie(m.streamId, ext), ext)
    }

    fun downloadEpisode(e: Episode, series: Series) {
        val r = repo ?: return
        val ext = e.ext ?: "mp4"
        startDownload("e${e.id}", "${series.name} - ${e.title ?: ""}", series.cover, r.urls.episode(e.id, ext), ext)
    }

    fun deleteDownload(key: String) {
        dl.remove(key)
        viewModelScope.launch { downloads = withContext(Dispatchers.IO) { dl.refresh() } }
    }

    fun playDownload(d: DownloadUi) {
        val path = d.path
        if (d.status == DlStatus.FAILED) {
            dl.retry(d.item.key)
            toast("إعادة المحاولة من حيث توقف...")
            return
        }
        if (d.status != DlStatus.DONE || path == null) {
            toast("التحميل لسه ما خلصش")
            return
        }
        play(Uri.fromFile(File(path)).toString(), d.item.title, null, false)
    }

    fun back() {
        val cur = screen
        if (cur is Screen.Player && cur.remote) dl.resumeAll()
        screen = when (screen) {
            is Screen.Player -> returnTo
            is Screen.SeriesDetail -> Screen.Home
            else -> screen
        }
    }

    fun logout() {
        store.clear()
        repo = null
        offline = false
        liveStreams = emptyList(); vodStreams = emptyList(); seriesList = emptyList()
        liveCats = emptyList(); vodCats = emptyList(); seriesCats = emptyList()
        screen = Screen.Login
    }
}
