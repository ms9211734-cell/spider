package com.spider.app.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.spider.app.data.SessionStore
import com.spider.app.data.model.*
import com.spider.app.data.repo.XtreamRepository
import kotlinx.coroutines.launch

sealed interface Screen {
    data object Login : Screen
    data object Home : Screen
    data class SeriesDetail(val series: Series) : Screen
    data class Player(val url: String, val title: String) : Screen
}

class SpiderViewModel(app: Application) : AndroidViewModel(app) {
    private val store = SessionStore(app)
    private var repo: XtreamRepository? = null
    private var returnTo: Screen = Screen.Home

    var screen by mutableStateOf<Screen>(Screen.Login)
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    val saved = store.load()

    var tab by mutableIntStateOf(0)
    var query by mutableStateOf("")
    var selectedCat by mutableStateOf<String?>(null)

    var liveCats by mutableStateOf<List<Category>>(emptyList())
    var liveStreams by mutableStateOf<List<LiveStream>>(emptyList())
    var vodCats by mutableStateOf<List<Category>>(emptyList())
    var vodStreams by mutableStateOf<List<VodStream>>(emptyList())
    var seriesCats by mutableStateOf<List<Category>>(emptyList())
    var seriesList by mutableStateOf<List<Series>>(emptyList())
    var episodes by mutableStateOf<Map<String, List<Episode>>>(emptyMap())

    init {
        saved?.let { login(it.first, it.second, it.third) }
    }

    fun login(server: String, user: String, pass: String) {
        var s = server.trim()
        if (s.isEmpty() || user.isBlank() || pass.isBlank()) {
            error = "اكتب كل البيانات"
            return
        }
        if (!s.startsWith("http")) s = "http://$s"
        loading = true
        error = null
        viewModelScope.launch {
            val r = try {
                XtreamRepository(s, user.trim(), pass.trim())
            } catch (e: Exception) {
                error = "رابط السيرفر غير صحيح"
                loading = false
                return@launch
            }
            r.login()
                .onSuccess {
                    repo = r
                    store.save(s, user.trim(), pass.trim())
                    screen = Screen.Home
                    loadTab(0)
                }
                .onFailure { error = it.message ?: "فشل الاتصال بالسيرفر" }
            loading = false
        }
    }

    fun loadTab(i: Int) {
        tab = i
        selectedCat = null
        query = ""
        error = null
        val r = repo ?: return
        viewModelScope.launch {
            loading = true
            when (i) {
                0 -> if (liveStreams.isEmpty()) {
                    r.liveCategories().onSuccess { liveCats = it }
                    r.liveStreams().onSuccess { liveStreams = it }.onFailure { error = it.message }
                }
                1 -> if (vodStreams.isEmpty()) {
                    r.vodCategories().onSuccess { vodCats = it }
                    r.vodStreams().onSuccess { vodStreams = it }.onFailure { error = it.message }
                }
                else -> if (seriesList.isEmpty()) {
                    r.seriesCategories().onSuccess { seriesCats = it }
                    r.seriesList().onSuccess { seriesList = it }.onFailure { error = it.message }
                }
            }
            loading = false
        }
    }

    fun openSeries(s: Series) {
        screen = Screen.SeriesDetail(s)
        episodes = emptyMap()
        error = null
        val r = repo ?: return
        viewModelScope.launch {
            loading = true
            r.seriesInfo(s.seriesId).onSuccess { episodes = it.episodes }.onFailure { error = it.message }
            loading = false
        }
    }

    private fun play(url: String, title: String) {
        returnTo = screen
        screen = Screen.Player(url, title)
    }

    fun playLive(s: LiveStream) = repo?.let { play(it.urls.live(s.streamId), s.name) }
    fun playMovie(m: VodStream) = repo?.let { play(it.urls.movie(m.streamId, m.ext), m.name) }
    fun playEpisode(e: Episode, seriesName: String) =
        repo?.let { play(it.urls.episode(e.id, e.ext), "$seriesName - ${e.title ?: ""}") }

    fun back() {
        screen = when (screen) {
            is Screen.Player -> returnTo
            is Screen.SeriesDetail -> Screen.Home
            else -> screen
        }
    }

    fun logout() {
        store.clear()
        repo = null
        liveStreams = emptyList(); vodStreams = emptyList(); seriesList = emptyList()
        liveCats = emptyList(); vodCats = emptyList(); seriesCats = emptyList()
        screen = Screen.Login
    }
}
