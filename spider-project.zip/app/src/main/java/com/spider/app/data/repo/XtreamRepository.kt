package com.spider.app.data.repo

import com.spider.app.data.model.*
import com.spider.app.data.remote.ApiFactory
import com.spider.app.data.remote.XtreamApi

class XtreamRepository(
    private val serverUrl: String,
    private val user: String,
    private val pass: String
) {
    private val api: XtreamApi = ApiFactory.create(serverUrl)
    val urls = StreamUrlBuilder(serverUrl, user, pass)

    suspend fun login(): Result<LoginResponse> = runCatching {
        val res = api.login(user, pass)
        check(res.userInfo?.auth == "1") { "بيانات الدخول غير صحيحة" }
        check(res.userInfo?.status.equals("Active", true)) { "الاشتراك منتهي أو غير مفعل" }
        res
    }

    suspend fun liveCategories() = runCatching { api.liveCategories(user, pass) }
    suspend fun liveStreams(cat: String? = null) = runCatching { api.liveStreams(user, pass, cat) }
    suspend fun vodCategories() = runCatching { api.vodCategories(user, pass) }
    suspend fun vodStreams(cat: String? = null) = runCatching { api.vodStreams(user, pass, cat) }
    suspend fun seriesCategories() = runCatching { api.seriesCategories(user, pass) }
    suspend fun seriesList(cat: String? = null) = runCatching { api.seriesList(user, pass, cat) }
    suspend fun seriesInfo(id: Int) = runCatching { api.seriesInfo(user, pass, id) }
    suspend fun epg(streamId: Int) = runCatching { api.shortEpg(user, pass, streamId) }
}
