plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("org.jetbrains.kotlin.plugin.serialization")
}

android {
    namespace = "com.spider.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.spider.app"
        minSdk = 24
        targetSdk = 34
        // رقم إصدار بيزيد تلقائياً مع كل بناء (بالدقايق)، علشان التحديث يتثبت فوق القديم
        versionCode = (System.currentTimeMillis() / 60000L).toInt()
        versionName = java.text.SimpleDateFormat("yyyy.MM.dd-HHmm").format(java.util.Date())
    }
    signingConfigs {
        create("spider") {
            storeFile = file("spider.keystore")
            storeType = "pkcs12"
            storePassword = "spider123"
            keyAlias = "spider"
            keyPassword = "spider123"
        }
    }
    buildTypes {
        debug { signingConfig = signingConfigs.getByName("spider") }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("spider")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")

    implementation("com.squareup.retrofit2:retrofit:2.11.0")
    implementation("com.squareup.retrofit2:converter-kotlinx-serialization:2.11.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.3")

    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.4.1")
    implementation("androidx.media3:media3-ui:1.4.1")

    implementation("io.coil-kt:coil-compose:2.7.0")
}
