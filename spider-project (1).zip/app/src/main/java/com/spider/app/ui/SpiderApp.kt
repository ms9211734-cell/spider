package com.spider.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color

@Composable
fun SpiderApp(vm: SpiderViewModel) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFFD70238), background = Color(0xFF0A0002), surface = Color(0xFF0A0002))) {
        Surface(Modifier.fillMaxSize()) {
            BackHandler(enabled = vm.screen is Screen.Player || vm.screen is Screen.SeriesDetail) {
                vm.back()
            }
            when (val s = vm.screen) {
                is Screen.Login -> LoginScreen(vm)
                is Screen.Home -> HomeScreen(vm)
                is Screen.SeriesDetail -> SeriesScreen(vm, s.series)
                is Screen.Player -> PlayerScreen(s.url, s.title)
            }
        }
    }
}
