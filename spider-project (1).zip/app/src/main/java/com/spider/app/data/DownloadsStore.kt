package com.spider.app.data

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json

@Serializable
data class DownloadItem(
    val key: String,
    val title: String,
    val poster: String? = null,
    val dmId: Long,
    val ext: String
)

enum class DlStatus { PENDING, RUNNING, PAUSED, DONE, FAILED }

data class DownloadUi(
    val item: DownloadItem,
    val status: DlStatus,
    val done: Long,
    val total: Long,
    val path: String?
) {
    val percent: Int get() = if (total > 0) ((done * 100) / total).toInt().coerceIn(0, 100) else 0
}

/** التحميل عن طريق DownloadManager بتاع النظام: بيكمّل في الخلفية وبيظهر إشعار بالتقدّم */
class DownloadsStore(private val ctx: Context) {
    private val dm = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    private val prefs = ctx.getSharedPreferences("downloads", Context.MODE_PRIVATE)
    private val json = Json { ignoreUnknownKeys = true }
    private val serializer = ListSerializer(DownloadItem.serializer())

    fun items(): List<DownloadItem> = try {
        json.decodeFromString(serializer, prefs.getString("items", "[]") ?: "[]")
    } catch (e: Exception) {
        emptyList()
    }

    private fun save(list: List<DownloadItem>) {
        prefs.edit().putString("items", json.encodeToString(serializer, list)).apply()
    }

    fun enqueue(key: String, title: String, poster: String?, url: String, ext: String): Boolean {
        if (items().any { it.key == key }) return false
        val req = DownloadManager.Request(Uri.parse(url))
            .setTitle(title)
            .setDescription("المصري سات")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalFilesDir(ctx, Environment.DIRECTORY_MOVIES, "$key.$ext")
        val id = dm.enqueue(req)
        save(items() + DownloadItem(key, title, poster, id, ext))
        return true
    }

    fun remove(key: String) {
        val item = items().firstOrNull { it.key == key } ?: return
        dm.remove(item.dmId)
        save(items().filter { it.key != key })
    }

    fun refresh(): List<DownloadUi> {
        val list = items()
        if (list.isEmpty()) return emptyList()
        val map = HashMap<Long, DownloadUi>()
        val q = DownloadManager.Query().setFilterById(*list.map { it.dmId }.toLongArray())
        dm.query(q)?.use { c ->
            val idI = c.getColumnIndexOrThrow(DownloadManager.COLUMN_ID)
            val stI = c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)
            val totI = c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
            val doneI = c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
            val uriI = c.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI)
            while (c.moveToNext()) {
                val id = c.getLong(idI)
                val item = list.firstOrNull { it.dmId == id } ?: continue
                val status = when (c.getInt(stI)) {
                    DownloadManager.STATUS_PENDING -> DlStatus.PENDING
                    DownloadManager.STATUS_RUNNING -> DlStatus.RUNNING
                    DownloadManager.STATUS_PAUSED -> DlStatus.PAUSED
                    DownloadManager.STATUS_SUCCESSFUL -> DlStatus.DONE
                    else -> DlStatus.FAILED
                }
                val path = c.getString(uriI)?.let { Uri.parse(it).path }
                map[id] = DownloadUi(item, status, c.getLong(doneI), c.getLong(totI), path)
            }
        }
        return list.map { map[it.dmId] ?: DownloadUi(it, DlStatus.FAILED, 0, 0, null) }
    }
}
