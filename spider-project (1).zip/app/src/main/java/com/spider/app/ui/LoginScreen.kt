package com.spider.app.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import com.spider.app.R
import kotlin.math.cos
import kotlin.math.sin

private val Red = Color(0xFFD70238)
private val DarkRed = Color(0xFF8B0A1E)

@Composable
fun LoginScreen(vm: SpiderViewModel) {
    var server by remember { mutableStateOf(vm.saved?.first ?: "") }
    var user by remember { mutableStateOf(vm.saved?.second ?: "") }
    var pass by remember { mutableStateOf(vm.saved?.third ?: "") }
    var showPass by remember { mutableStateOf(false) }

    val inf = rememberInfiniteTransition(label = "spider")
    val bob by inf.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(2600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "bob"
    )
    val glow by inf.animateFloat(
        0.4f, 1f,
        infiniteRepeatable(tween(1800), RepeatMode.Reverse),
        label = "glow"
    )
    val appear = remember { Animatable(0f) }
    LaunchedEffect(Unit) { appear.animateTo(1f, tween(900)) }

    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF0A0002), Color(0xFF16020A), Color(0xFF0A0002)))
        )
    ) {
        WebBackground(Modifier.fillMaxSize())

        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            SpiderLogo(
                Modifier.padding(top = 24.dp).fillMaxWidth(0.9f).widthIn(max = 340.dp).aspectRatio(1f)
                    .offset { IntOffset(0, (bob * 10.dp.toPx()).toInt()) },
                glow
            )
            Text(
                "مشغّل IPTV بسيط وسريع", color = Color.White.copy(alpha = 0.55f),
                fontSize = 13.sp, modifier = Modifier.padding(bottom = 20.dp)
            )

            // الكارت الزجاجي
            Column(
                Modifier
                    .graphicsLayer {
                        alpha = appear.value
                        translationY = (1f - appear.value) * 60f
                    }
                    .widthIn(max = 440.dp).fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color.White.copy(alpha = 0.06f))
                    .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(24.dp))
                    .padding(20.dp)
            ) {
                Text("تسجيل الدخول", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(
                    "ادخل ببيانات اشتراكك", color = Color.White.copy(alpha = 0.55f),
                    fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp, bottom = 16.dp)
                )

                SpiderField(
                    value = server, onChange = { server = it }, label = "رابط السيرفر", icon = "🌐",
                    keyboardType = KeyboardType.Uri, ime = ImeAction.Next
                )
                Spacer(Modifier.height(10.dp))
                SpiderField(
                    value = user, onChange = { user = it }, label = "اسم المستخدم", icon = "👤",
                    ime = ImeAction.Next
                )
                Spacer(Modifier.height(10.dp))
                SpiderField(
                    value = pass, onChange = { pass = it }, label = "كلمة المرور", icon = "🔒",
                    keyboardType = KeyboardType.Password, ime = ImeAction.Done,
                    onDone = { vm.login(server, user, pass) },
                    visual = if (showPass) VisualTransformation.None else PasswordVisualTransformation(),
                    trailing = {
                        Text(
                            if (showPass) "🙈" else "👁",
                            modifier = Modifier.clickable { showPass = !showPass }.padding(8.dp)
                        )
                    }
                )

                vm.error?.let {
                    Text(it, color = Color(0xFFFF8A80), fontSize = 13.sp, modifier = Modifier.padding(top = 12.dp))
                }

                Spacer(Modifier.height(18.dp))
                Box(
                    Modifier.fillMaxWidth().height(54.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Brush.horizontalGradient(listOf(Red, DarkRed)))
                        .clickable(enabled = !vm.loading) { vm.login(server, user, pass) },
                    contentAlignment = Alignment.Center
                ) {
                    if (vm.loading) {
                        CircularProgressIndicator(Modifier.size(24.dp), color = Color.White, strokeWidth = 2.5.dp)
                    } else {
                        Text("دخول", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Text(
                "Spider مشغّل فقط ولا يحتوي على أي قنوات أو محتوى.\nأدخل بيانات اشتراكك الخاص من مزوّدك.",
                color = Color.White.copy(alpha = 0.35f), fontSize = 11.sp, textAlign = TextAlign.Center,
                modifier = Modifier.padding(vertical = 20.dp)
            )
        }
    }
}

@Composable
private fun SpiderField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    icon: String,
    keyboardType: KeyboardType = KeyboardType.Text,
    ime: ImeAction = ImeAction.Next,
    onDone: () -> Unit = {},
    visual: VisualTransformation = VisualTransformation.None,
    trailing: @Composable (() -> Unit)? = null
) {
    OutlinedTextField(
        value = value, onValueChange = onChange, singleLine = true,
        label = { Text(label) },
        leadingIcon = { Text(icon, modifier = Modifier.padding(start = 8.dp)) },
        trailingIcon = trailing,
        visualTransformation = visual,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType, imeAction = ime),
        keyboardActions = KeyboardActions(onDone = { onDone() }),
        shape = RoundedCornerShape(14.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Red,
            unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White,
            cursorColor = Red,
            focusedLabelColor = Red,
            unfocusedLabelColor = Color.White.copy(alpha = 0.6f)
        ),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun SpiderLogo(modifier: Modifier, glow: Float) {
    val bmp = ImageBitmap.imageResource(R.drawable.spider_logo)
    Canvas(modifier) {
        val c = Offset(size.width / 2, size.height * 0.45f)
        val rad = size.width * 0.55f
        drawCircle(
            Brush.radialGradient(listOf(Red.copy(alpha = 0.35f * glow), Color.Transparent), center = c, radius = rad),
            radius = rad, center = c
        )
        // Screen: الأسود في الصورة يختفي وتندمج مع الخلفية
        drawImage(
            bmp, dstSize = IntSize(size.width.toInt(), size.height.toInt()),
            blendMode = BlendMode.Screen
        )
    }
}

@Composable
private fun WebBackground(modifier: Modifier) {
    Canvas(modifier) {
        val origin = Offset(size.width / 2, 0f)
        val maxR = size.height * 0.8f
        val spokes = 11
        val angles = (0 until spokes).map { Math.toRadians(8.0 + it * (164.0 / (spokes - 1))) }
        val lineColor = Red.copy(alpha = 0.16f)

        fun pt(a: Double, rad: Float) =
            Offset(origin.x + (cos(a) * rad).toFloat(), origin.y + (sin(a) * rad).toFloat())

        angles.forEach { a -> drawLine(lineColor, origin, pt(a, maxR), strokeWidth = 1.5f) }

        for (ring in 1..9) {
            val rad = maxR * ring / 9f
            val path = Path()
            angles.forEachIndexed { i, a ->
                val p = pt(a, rad)
                if (i == 0) {
                    path.moveTo(p.x, p.y)
                } else {
                    val mid = pt((a + angles[i - 1]) / 2, rad * 0.93f)
                    path.quadraticBezierTo(mid.x, mid.y, p.x, p.y)
                }
            }
            drawPath(path, lineColor, style = Stroke(width = 1.5f))
        }
    }
}
