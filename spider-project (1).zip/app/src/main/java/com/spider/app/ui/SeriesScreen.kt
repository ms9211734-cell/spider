package com.spider.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.spider.app.data.model.Series

@Composable
fun SeriesScreen(vm: SpiderViewModel, series: Series) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp)) {
        item {
            Column {
                Text(series.name, style = MaterialTheme.typography.titleLarge)
                val plot = series.plot
                if (!plot.isNullOrBlank()) Text(plot, modifier = Modifier.padding(vertical = 8.dp))
                if (vm.loading) LinearProgressIndicator(Modifier.fillMaxWidth())
                vm.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        }
        val seasons = vm.episodes.toSortedMap(compareBy<String> { it.toIntOrNull() ?: 0 })
        seasons.forEach { (season, eps) ->
            item {
                Text(
                    "الموسم $season", style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(top = 16.dp, bottom = 4.dp)
                )
            }
            items(eps) { ep ->
                Row(
                    Modifier.fillMaxWidth()
                        .clickable { vm.playEpisode(ep, series.name) }
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("${ep.num ?: ""}. ${ep.title ?: ""}", modifier = Modifier.weight(1f))
                    DownloadBadge(vm.statusOf("e${ep.id}"), { vm.downloadEpisode(ep, series) })
                }
            }
        }
    }
}
